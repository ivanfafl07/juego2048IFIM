import 'dart:convert';

import 'package:crypto/crypto.dart';

// La contraseña se guarda como hash SHA-256, nunca en texto plano
String encriptarContrasena(String contrasena) {
  return sha256.convert(utf8.encode(contrasena)).toString();
}

// Validadores para los TextFormField (devuelven null si está bien)
String? validarObligatorio(String? valor) {
  if (valor == null || valor.trim().isEmpty) return 'Campo obligatorio';
  return null;
}

String? validarEmail(String? valor) {
  final formato = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
  if (valor == null || !formato.hasMatch(valor.trim())) return 'Email no válido';
  return null;
}

String? validarContrasena(String? valor) {
  if (valor == null || valor.length < 4) return 'Mínimo 4 caracteres';
  return null;
}

// 125 -> "02:05"
String formatearDuracion(int segundos) {
  final min = (segundos ~/ 60).toString().padLeft(2, '0');
  final seg = (segundos % 60).toString().padLeft(2, '0');
  return '$min:$seg';
}

// "2026-11-24T17:30:12.000" -> "24/11/2026 17:30"
String formatearFecha(String iso) {
  final f = DateTime.parse(iso);
  String dos(int n) => n.toString().padLeft(2, '0');
  return '${dos(f.day)}/${dos(f.month)}/${f.year} ${dos(f.hour)}:${dos(f.minute)}';
}

// "Exception: texto" -> "texto"
String textoError(Object error) => error.toString().replaceFirst('Exception: ', '');
