import 'package:flutter/material.dart';

import '../data/partida_dao.dart';
import '../routes.dart';
import '../services/sesion.dart';
import '../services/tema_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/tile_widget.dart';

class AjustesScreen extends StatelessWidget {
  const AjustesScreen({super.key});

  Future<void> _borrarHistorial(BuildContext context) async {
    final respuesta = await ConfirmDialog.mostrar(
      context,
      titulo: 'Borrar historial',
      mensaje: 'Se borrarán TODAS las partidas del historial. No se puede deshacer.',
      textoConfirmar: 'Borrar todo',
    );
    if (respuesta != RespuestaDialogo.confirmar) return;

    var mensaje = 'Historial borrado';
    try {
      await PartidaDao().eliminarTodas();
    } catch (e) {
      mensaje = 'Error al borrar el historial';
    }
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mensaje)));
    }
  }

  void _cerrarSesion(BuildContext context) {
    Sesion.usuario = null;
    Navigator.pushNamedAndRemoveUntil(context, AppRoutes.login, (ruta) => false);
  }

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);

    // Se redibuja al momento cuando cambia el tema o la paleta
    return ListenableBuilder(
      listenable: temaController,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('Ajustes')),
          body: ListView(
            padding: const EdgeInsets.all(AppTheme.espacio),
            children: [
              Text('Tema', style: tema.textTheme.titleMedium),
              const SizedBox(height: AppTheme.espacio / 2),
              SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment(value: ThemeMode.light, label: Text('Claro'), icon: Icon(Icons.light_mode)),
                  ButtonSegment(value: ThemeMode.dark, label: Text('Oscuro'), icon: Icon(Icons.dark_mode)),
                  ButtonSegment(value: ThemeMode.system, label: Text('Sistema'), icon: Icon(Icons.phone_android)),
                ],
                selected: {temaController.modo},
                onSelectionChanged: (seleccion) => temaController.cambiarModo(seleccion.first),
              ),
              const SizedBox(height: AppTheme.espacio),
              Text('Color de las fichas', style: tema.textTheme.titleMedium),
              const SizedBox(height: AppTheme.espacio / 2),
              Wrap(
                spacing: AppTheme.espacio / 2,
                children: [
                  for (var i = 0; i < AppTheme.nombresPaletas.length; i++)
                    ChoiceChip(
                      label: Text(AppTheme.nombresPaletas[i]),
                      selected: temaController.paletaFichas == i,
                      onSelected: (_) => temaController.cambiarPaleta(i),
                    ),
                ],
              ),
              const SizedBox(height: AppTheme.espacio / 2),
              // Vista previa de las fichas con la paleta elegida
              Row(
                children: [
                  for (final valor in [2, 8, 32, 128, 512, 2048])
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(AppTheme.espacioPequeno),
                        child: AspectRatio(aspectRatio: 1, child: TileWidget(valor: valor)),
                      ),
                    ),
                ],
              ),
              const Divider(height: AppTheme.espacio * 2),
              ListTile(
                leading: Icon(Icons.delete_forever, color: tema.colorScheme.error),
                title: const Text('Borrar todo el historial'),
                onTap: () => _borrarHistorial(context),
              ),
              ListTile(
                leading: const Icon(Icons.logout),
                title: Text('Cerrar sesión (${Sesion.nombre})'),
                onTap: () => _cerrarSesion(context),
              ),
            ],
          ),
        );
      },
    );
  }
}
