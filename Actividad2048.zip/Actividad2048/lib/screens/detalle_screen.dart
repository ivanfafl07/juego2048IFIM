import 'package:flutter/material.dart';

import '../data/partida_dao.dart';
import '../models/partida.dart';
import '../theme/app_theme.dart';
import '../utils.dart';
import '../widgets/async_data_view.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/empty_state_view.dart';
import '../widgets/stat_card.dart';
import '../widgets/tile_widget.dart';

// Recibe solo el id y consulta la partida en la BD
class DetalleScreen extends StatefulWidget {
  final int partidaId;

  const DetalleScreen({super.key, required this.partidaId});

  @override
  State<DetalleScreen> createState() => _DetalleScreenState();
}

class _DetalleScreenState extends State<DetalleScreen> {
  final _dao = PartidaDao();
  late Future<Partida?> _partida = _dao.obtenerPorId(widget.partidaId);

  void _recargar() {
    setState(() => _partida = _dao.obtenerPorId(widget.partidaId));
  }

  Future<void> _eliminar() async {
    final respuesta = await ConfirmDialog.mostrar(
      context,
      titulo: 'Eliminar partida',
      mensaje: 'Esta partida se borrará del historial.',
      textoConfirmar: 'Eliminar',
    );
    if (respuesta != RespuestaDialogo.confirmar) return;
    try {
      await _dao.eliminar(widget.partidaId);
      if (mounted) Navigator.pop(context, true); // true = "se ha borrado", el historial se actualiza
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Error al eliminar la partida')));
      }
    }
  }

  Widget _contenido(BuildContext context, Partida? partida) {
    if (partida == null) {
      return const Center(child: EmptyStateView(icono: Icons.search_off, mensaje: 'Esta partida ya no existe'));
    }
    return ListView(
      padding: const EdgeInsets.all(AppTheme.espacio),
      children: [
        Center(
          child: SizedBox(
            width: AppTheme.tamanoFichaLista * 2,
            height: AppTheme.tamanoFichaLista * 2,
            child: TileWidget(valor: partida.fichaMaxima),
          ),
        ),
        const SizedBox(height: AppTheme.espacio),
        Wrap(
          alignment: WrapAlignment.center,
          children: [
            StatCard(titulo: 'Jugador', valor: partida.usuario, icono: Icons.person),
            StatCard(titulo: 'Puntuación', valor: '${partida.puntuacion}', icono: Icons.star),
            StatCard(titulo: 'Ficha máxima', valor: '${partida.fichaMaxima}', icono: Icons.grid_view),
            StatCard(titulo: 'Movimientos', valor: '${partida.movimientos}', icono: Icons.swipe),
            StatCard(titulo: 'Duración', valor: formatearDuracion(partida.duracionSegundos), icono: Icons.timer),
            StatCard(titulo: 'Fecha', valor: formatearFecha(partida.fecha), icono: Icons.calendar_today),
            StatCard(titulo: 'Tablero', valor: '${partida.tamanoTablero}x${partida.tamanoTablero}', icono: Icons.grid_4x4),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle de la partida'),
        actions: [IconButton(icon: const Icon(Icons.delete), tooltip: 'Eliminar', onPressed: _eliminar)],
      ),
      body: AsyncDataView<Partida?>(
        future: _partida,
        onReintentar: _recargar,
        builder: _contenido,
      ),
    );
  }
}
