import 'package:flutter/material.dart';

import '../data/partida_dao.dart';
import '../models/estadisticas.dart';
import '../models/partida.dart';
import '../theme/app_theme.dart';
import '../utils.dart';
import '../widgets/async_data_view.dart';
import '../widgets/empty_state_view.dart';
import '../widgets/partida_list_item.dart';
import '../widgets/stat_card.dart';

// Junta los resultados de las tres consultas que necesita esta pantalla
class DatosRanking {
  final List<Partida> top10;
  final EstadisticasGlobales globales;
  final List<EstadisticaJugador> porJugador;

  const DatosRanking(this.top10, this.globales, this.porJugador);
}

class RankingScreen extends StatefulWidget {
  const RankingScreen({super.key});

  @override
  State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen> {
  final _dao = PartidaDao();
  late Future<DatosRanking> _datos = _consultar();

  Future<DatosRanking> _consultar() async {
    final top = await _dao.top10();
    final globales = await _dao.estadisticasGlobales();
    final jugadores = await _dao.estadisticasPorJugador();
    return DatosRanking(top, globales, jugadores);
  }

  Future<void> _recargar() async {
    if (!mounted) return;
    setState(() => _datos = _consultar());
    try {
      await _datos;
    } catch (_) {
      // Lo muestra AsyncDataView
    }
  }

  Widget _titulo(BuildContext context, String texto) {
    return Padding(
      padding: const EdgeInsets.only(top: AppTheme.espacio, bottom: AppTheme.espacio / 2),
      child: Text(texto, style: Theme.of(context).textTheme.titleMedium),
    );
  }

  Widget _contenido(BuildContext context, DatosRanking datos) {
    final g = datos.globales;
    return RefreshIndicator(
      onRefresh: _recargar,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(AppTheme.espacio),
        children: [
          if (g.partidasJugadas == 0)
            const EmptyStateView(icono: Icons.emoji_events, mensaje: 'Todavía no hay partidas terminadas')
          else ...[
            _titulo(context, 'Estadísticas globales'),
            Wrap(
              alignment: WrapAlignment.center,
              children: [
                StatCard(titulo: 'Partidas jugadas', valor: '${g.partidasJugadas}', icono: Icons.videogame_asset),
                StatCard(titulo: 'Puntuación máxima', valor: '${g.puntuacionMaxima}', icono: Icons.star),
                StatCard(titulo: 'Puntuación media', valor: g.puntuacionMedia.toStringAsFixed(1), icono: Icons.functions),
                StatCard(titulo: 'Ficha máxima', valor: '${g.fichaMaxima}', icono: Icons.grid_view),
                StatCard(titulo: 'Tiempo total', valor: formatearDuracion(g.tiempoTotalSegundos), icono: Icons.timer),
              ],
            ),
            _titulo(context, 'Top 10'),
            for (var i = 0; i < datos.top10.length; i++) PartidaListItem(partida: datos.top10[i], posicion: i + 1),
            _titulo(context, 'Por jugador'),
            for (final j in datos.porJugador)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(j.usuario),
                  subtitle: Text('${j.numPartidas} partidas'),
                  trailing: Text('Mejor: ${j.mejorPuntuacion}'),
                ),
              ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ranking y estadísticas')),
      body: AsyncDataView<DatosRanking>(
        future: _datos,
        onReintentar: _recargar,
        builder: _contenido,
      ),
    );
  }
}
