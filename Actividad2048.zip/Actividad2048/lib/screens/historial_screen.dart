import 'package:flutter/material.dart';

import '../data/partida_dao.dart';
import '../models/partida.dart';
import '../routes.dart';
import '../theme/app_theme.dart';
import '../widgets/async_data_view.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/empty_state_view.dart';
import '../widgets/partida_list_item.dart';

class HistorialScreen extends StatefulWidget {
  const HistorialScreen({super.key});

  @override
  State<HistorialScreen> createState() => _HistorialScreenState();
}

class _HistorialScreenState extends State<HistorialScreen> {
  static const List<int> opcionesFicha = [0, 128, 256, 512, 1024, 2048]; // 0 = todas

  final _dao = PartidaDao();
  String _filtroJugador = '';
  int _filtroFicha = 0;
  late Future<List<Partida>> _partidas = _consultar();

  Future<List<Partida>> _consultar() {
    return _dao.obtenerHistorial(jugador: _filtroJugador, fichaMinima: _filtroFicha);
  }

  // Vuelve a consultar la BD (filtros, arrastrar hacia abajo, después de borrar...)
  Future<void> _recargar() async {
    if (!mounted) return;
    setState(() => _partidas = _consultar());
    try {
      await _partidas; // Para que el RefreshIndicator sepa cuándo ha terminado
    } catch (_) {
      // El error ya lo muestra AsyncDataView con su botón de reintentar
    }
  }

  void _aviso(String texto, {SnackBarAction? accion}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto), action: accion));
  }

  // Borra y ofrece "Deshacer", que vuelve a insertar la misma partida
  Future<void> _eliminar(Partida partida) async {
    try {
      await _dao.eliminar(partida.id!);
      _aviso('Partida eliminada', accion: SnackBarAction(label: 'Deshacer', onPressed: () => _deshacer(partida)));
    } catch (e) {
      _aviso('Error al eliminar la partida');
    }
    _recargar();
  }

  Future<void> _deshacer(Partida partida) async {
    try {
      await _dao.insertar(partida);
      _aviso('Partida recuperada');
    } catch (e) {
      _aviso('No se pudo recuperar la partida');
    }
    _recargar();
  }

  // Se pasa solo el id. Si el detalle devuelve true es que la partida se ha borrado allí
  Future<void> _abrirDetalle(Partida partida) async {
    final resultado = await Navigator.pushNamed(context, AppRoutes.detalle, arguments: partida.id);
    if (resultado == true) {
      _aviso('Partida eliminada');
      _recargar();
    }
  }

  // Pulsación larga: menú con opciones
  void _mostrarMenu(Partida partida) {
    showModalBottomSheet<void>(
      context: context,
      builder: (contextoMenu) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('Ver detalle'),
              onTap: () {
                Navigator.pop(contextoMenu);
                _abrirDetalle(partida);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Eliminar'),
              onTap: () async {
                Navigator.pop(contextoMenu);
                final respuesta = await ConfirmDialog.mostrar(
                  context,
                  titulo: 'Eliminar partida',
                  mensaje: '¿Seguro que quieres eliminar esta partida?',
                  textoConfirmar: 'Eliminar',
                );
                if (respuesta == RespuestaDialogo.confirmar) _eliminar(partida);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _filtros() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.espacio),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: const InputDecoration(labelText: 'Filtrar por jugador', prefixIcon: Icon(Icons.search)),
              onChanged: (texto) {
                _filtroJugador = texto.trim();
                _recargar();
              },
            ),
          ),
          const SizedBox(width: AppTheme.espacio),
          DropdownButton<int>(
            value: _filtroFicha,
            items: [
              for (final ficha in opcionesFicha)
                DropdownMenuItem(value: ficha, child: Text(ficha == 0 ? 'Todas' : '≥ $ficha')),
            ],
            onChanged: (valor) {
              _filtroFicha = valor ?? 0;
              _recargar();
            },
          ),
        ],
      ),
    );
  }

  Widget _lista(BuildContext context, List<Partida> partidas) {
    // RefreshIndicator: arrastrar hacia abajo vuelve a consultar la BD.
    // AlwaysScrollableScrollPhysics para que funcione aunque la lista sea corta o esté vacía
    return RefreshIndicator(
      onRefresh: _recargar,
      child: partidas.isEmpty
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: const [EmptyStateView(icono: Icons.history, mensaje: 'No hay partidas que mostrar')],
            )
          : ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(AppTheme.espacio / 2),
              itemCount: partidas.length,
              itemBuilder: (context, i) {
                final partida = partidas[i];
                // Deslizar para descartar, con SnackBar "Deshacer"
                return Dismissible(
                  key: ValueKey(partida.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: AppTheme.espacio),
                    color: Theme.of(context).colorScheme.error,
                    child: Icon(Icons.delete, color: Theme.of(context).colorScheme.onError),
                  ),
                  onDismissed: (_) {
                    setState(() => partidas.removeAt(i)); // Se quita de la pantalla al instante
                    _eliminar(partida);
                  },
                  child: PartidaListItem(
                    partida: partida,
                    onTap: () => _abrirDetalle(partida),
                    onLongPress: () => _mostrarMenu(partida),
                  ),
                );
              },
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historial')),
      body: Column(
        children: [
          _filtros(),
          Expanded(
            child: AsyncDataView<List<Partida>>(
              future: _partidas,
              onReintentar: _recargar,
              builder: _lista,
            ),
          ),
        ],
      ),
    );
  }
}
