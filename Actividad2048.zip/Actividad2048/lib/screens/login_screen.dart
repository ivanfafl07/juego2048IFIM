import 'package:flutter/material.dart';

import '../data/usuario_dao.dart';
import '../models/usuario.dart';
import '../routes.dart';
import '../services/preferencias_service.dart';
import '../services/sesion.dart';
import '../theme/app_theme.dart';
import '../utils.dart';

// Una sola pantalla para entrar y para registrarse (se cambia con el botón de abajo)
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formulario = GlobalKey<FormState>();
  final _usuarioCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _contrasenaCtrl = TextEditingController();
  final _usuarioDao = UsuarioDao();

  bool _modoRegistro = false;
  bool _cargando = false;

  @override
  void initState() {
    super.initState();
    _rellenarUltimoJugador();
  }

  // shared_preferences: escribimos el nombre del último que entró
  Future<void> _rellenarUltimoJugador() async {
    final nombre = await PreferenciasService.leerUltimoJugador();
    if (mounted && _usuarioCtrl.text.isEmpty) _usuarioCtrl.text = nombre;
  }

  @override
  void dispose() {
    _usuarioCtrl.dispose();
    _emailCtrl.dispose();
    _contrasenaCtrl.dispose();
    super.dispose();
  }

  Future<void> _enviar() async {
    if (!_formulario.currentState!.validate()) return;
    setState(() => _cargando = true);

    final nombre = _usuarioCtrl.text.trim();
    final hash = encriptarContrasena(_contrasenaCtrl.text);

    try {
      Usuario? usuario;
      if (_modoRegistro) {
        usuario = await _usuarioDao.registrar(Usuario(
          usuario: nombre,
          email: _emailCtrl.text.trim(),
          contrasena: hash,
          fechaRegistro: DateTime.now().toIso8601String(),
        ));
      } else {
        usuario = await _usuarioDao.login(nombre, hash);
      }

      if (usuario == null) {
        _aviso('Usuario o contraseña incorrectos');
        return;
      }

      Sesion.usuario = usuario;
      await PreferenciasService.guardarUltimoJugador(usuario.usuario);
      if (mounted) Navigator.pushReplacementNamed(context, AppRoutes.principal);
    } catch (e) {
      _aviso(textoError(e));
    } finally {
      if (mounted) setState(() => _cargando = false);
    }
  }

  void _aviso(String texto) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_modoRegistro ? 'Crear cuenta' : 'Iniciar sesión')),
      body: Form(
        key: _formulario,
        child: ListView(
          padding: const EdgeInsets.all(AppTheme.espacio),
          children: [
            const Text('2048', style: AppTheme.estiloTitulo, textAlign: TextAlign.center),
            TextFormField(
              controller: _usuarioCtrl,
              decoration: const InputDecoration(labelText: 'Usuario', prefixIcon: Icon(Icons.person)),
              validator: validarObligatorio,
            ),
            if (_modoRegistro)
              TextFormField(
                controller: _emailCtrl,
                decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email)),
                keyboardType: TextInputType.emailAddress,
                validator: validarEmail,
              ),
            TextFormField(
              controller: _contrasenaCtrl,
              decoration: const InputDecoration(labelText: 'Contraseña', prefixIcon: Icon(Icons.lock)),
              obscureText: true,
              validator: validarContrasena,
            ),
            const SizedBox(height: AppTheme.espacio),
            FilledButton(
              onPressed: _cargando ? null : _enviar,
              child: Text(_modoRegistro ? 'Registrarse' : 'Entrar'),
            ),
            TextButton(
              onPressed: () => setState(() => _modoRegistro = !_modoRegistro),
              child: Text(_modoRegistro ? 'Ya tengo cuenta' : 'No tengo cuenta, quiero registrarme'),
            ),
          ],
        ),
      ),
    );
  }
}
