import 'package:flutter/material.dart';

import 'ajustes_screen.dart';
import 'historial_screen.dart';
import 'inicio_screen.dart';
import 'ranking_screen.dart';

// Navegación principal con BottomNavigationBar: las 4 secciones siempre a un toque
class PrincipalScreen extends StatefulWidget {
  const PrincipalScreen({super.key});

  @override
  State<PrincipalScreen> createState() => _PrincipalScreenState();
}

class _PrincipalScreenState extends State<PrincipalScreen> {
  int _pestana = 0;

  void _irA(int pestana) => setState(() => _pestana = pestana);

  @override
  Widget build(BuildContext context) {
    // Cada vez que se cambia de pestaña la pantalla se crea de nuevo y vuelve a leer la BD
    final Widget pantalla = switch (_pestana) {
      1 => const HistorialScreen(),
      2 => const RankingScreen(),
      3 => const AjustesScreen(),
      _ => InicioScreen(onIrAPestana: _irA),
    };

    return Scaffold(
      body: pantalla,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _pestana,
        onTap: _irA,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Inicio'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Historial'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'Ranking'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Ajustes'),
        ],
      ),
    );
  }
}
