import 'dart:async';

import 'package:flutter/material.dart';

import '../data/partida_dao.dart';
import '../data/partida_guardada_dao.dart';
import '../logic/juego_2048.dart';
import '../models/partida.dart';
import '../models/partida_guardada.dart';
import '../services/preferencias_service.dart';
import '../services/sesion.dart';
import '../theme/app_theme.dart';
import '../utils.dart';
import '../widgets/board_widget.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/score_card.dart';

class JuegoScreen extends StatefulWidget {
  final bool continuar; // true = cargar la partida guardada de la BD

  const JuegoScreen({super.key, required this.continuar});

  @override
  State<JuegoScreen> createState() => _JuegoScreenState();
}

// WidgetsBindingObserver: para enterarnos de cuándo la app pasa a segundo plano
class _JuegoScreenState extends State<JuegoScreen> with WidgetsBindingObserver {
  final _partidaDao = PartidaDao();
  final _guardadaDao = PartidaGuardadaDao();

  Juego2048 _juego = Juego2048();
  int _segundos = 0;
  int _mejor = 0;
  bool _cargando = true;
  bool _terminada = false;
  bool _verDetalles = true; // Se cambia con doble toque en la puntuación
  Timer? _cronometro;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _prepararPartida();
  }

  @override
  void dispose() {
    _cronometro?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // Guardado automático al pasar a segundo plano (botón home, cambiar de app...)
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused && !_terminada && !_cargando) {
      _guardarPartida();
    }
  }

  Future<void> _prepararPartida() async {
    try {
      _mejor = await PreferenciasService.leerMejorPuntuacion();
      if (widget.continuar) {
        final guardada = await _guardadaDao.obtener(Sesion.nombre);
        if (guardada != null) {
          _juego = Juego2048.desdeGuardado(guardada.tablero, guardada.puntuacion, guardada.movimientos);
          _segundos = guardada.segundosTranscurridos;
        }
      }
    } catch (e) {
      _aviso('No se pudo cargar la partida guardada, empiezas una nueva');
    }
    if (!mounted) return;
    setState(() => _cargando = false);
    _arrancarCronometro();
  }

  void _arrancarCronometro() {
    _cronometro?.cancel();
    _cronometro = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _segundos++);
    });
  }

  void _aviso(String texto) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  // Devuelve true si se ha guardado bien
  Future<bool> _guardarPartida() async {
    try {
      await _guardadaDao.guardar(PartidaGuardada(
        usuario: Sesion.nombre,
        tablero: _juego.tablero,
        puntuacion: _juego.puntuacion,
        movimientos: _juego.movimientos,
        segundosTranscurridos: _segundos,
      ));
      return true;
    } catch (e) {
      _aviso('Error al guardar la partida');
      return false;
    }
  }

  void _mover(Direccion direccion) {
    if (_cargando || _terminada) return;
    final haCambiado = _juego.mover(direccion);
    if (!haCambiado) return;
    setState(() {});
    if (_juego.sinMovimientos) _finDePartida();
  }

  Future<void> _finDePartida() async {
    _cronometro?.cancel();
    setState(() => _terminada = true);

    final partida = Partida(
      usuario: Sesion.nombre,
      puntuacion: _juego.puntuacion,
      fichaMaxima: _juego.fichaMaxima,
      movimientos: _juego.movimientos,
      duracionSegundos: _segundos,
      fecha: DateTime.now().toIso8601String(),
    );

    try {
      await _partidaDao.registrarPartidaTerminada(partida); // Transacción: historial + borrar guardada
      if (partida.puntuacion > _mejor) {
        _mejor = partida.puntuacion;
        await PreferenciasService.guardarMejorPuntuacion(_mejor);
      }
    } catch (e) {
      _aviso('Error al guardar la partida en el historial');
    }

    if (!mounted) return;
    final respuesta = await ConfirmDialog.mostrar(
      context,
      titulo: 'Fin de la partida',
      mensaje: 'Puntuación: ${partida.puntuacion}\nFicha máxima: ${partida.fichaMaxima}',
      textoConfirmar: 'Jugar de nuevo',
      textoCancelar: 'Volver al inicio',
    );
    if (!mounted) return;
    if (respuesta == RespuestaDialogo.confirmar) {
      _empezarDeNuevo();
    } else {
      Navigator.pop(context);
    }
  }

  void _empezarDeNuevo() {
    setState(() {
      _juego = Juego2048();
      _segundos = 0;
      _terminada = false;
    });
    _arrancarCronometro();
  }

  Future<void> _confirmarReinicio() async {
    final respuesta = await ConfirmDialog.mostrar(
      context,
      titulo: 'Reiniciar',
      mensaje: 'Se perderá la partida actual. ¿Seguro?',
      textoConfirmar: 'Reiniciar',
    );
    if (respuesta == RespuestaDialogo.confirmar) _empezarDeNuevo();
  }

  // Botón atrás con partida en curso: guardar y salir / salir sin guardar / cancelar
  Future<void> _preguntarAntesDeSalir() async {
    final respuesta = await ConfirmDialog.mostrar(
      context,
      titulo: 'Salir de la partida',
      mensaje: '¿Quieres guardar la partida para continuarla después?',
      textoConfirmar: 'Guardar y salir',
      textoAlternativo: 'Salir sin guardar',
    );
    if (respuesta == RespuestaDialogo.cancelar || !mounted) return;

    if (respuesta == RespuestaDialogo.confirmar) {
      final guardado = await _guardarPartida();
      if (!guardado) return; // Si falla no salimos, para no perder la partida
      _aviso('Partida guardada');
    }
    if (mounted) Navigator.pop(context);
  }

  // Puntuación + mejor. Doble toque: mostrar u ocultar movimientos y tiempo
  Widget _marcador() {
    final mejorMostrado = _juego.puntuacion > _mejor ? _juego.puntuacion : _mejor;
    return GestureDetector(
      onDoubleTap: () => setState(() => _verDetalles = !_verDetalles),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: ScoreCard(etiqueta: 'PUNTOS', valor: _juego.puntuacion)),
              Expanded(child: ScoreCard(etiqueta: 'MEJOR', valor: mejorMostrado)),
            ],
          ),
          if (_verDetalles)
            Padding(
              padding: const EdgeInsets.all(AppTheme.espacioPequeno),
              child: Text('Movimientos: ${_juego.movimientos}    Tiempo: ${formatearDuracion(_segundos)}'),
            ),
        ],
      ),
    );
  }

  // Alternativa accesible al gesto: botones de dirección
  Widget _botonesDireccion() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton.filledTonal(onPressed: () => _mover(Direccion.izquierda), icon: const Icon(Icons.arrow_back)),
        IconButton.filledTonal(onPressed: () => _mover(Direccion.arriba), icon: const Icon(Icons.arrow_upward)),
        IconButton.filledTonal(onPressed: () => _mover(Direccion.abajo), icon: const Icon(Icons.arrow_downward)),
        IconButton.filledTonal(onPressed: () => _mover(Direccion.derecha), icon: const Icon(Icons.arrow_forward)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final tablero = Center(child: BoardWidget(tablero: _juego.tablero, onMover: _mover));
    final horizontal = MediaQuery.of(context).orientation == Orientation.landscape;

    return PopScope(
      canPop: _terminada, // Con la partida en marcha no se sale directamente
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _preguntarAntesDeSalir();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('2048'),
          actions: [
            IconButton(icon: const Icon(Icons.refresh), tooltip: 'Reiniciar', onPressed: _confirmarReinicio),
          ],
        ),
        body: _cargando
            ? const Center(child: CircularProgressIndicator())
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(AppTheme.espacio),
                  // En horizontal: tablero a la izquierda y marcador + botones a la derecha
                  child: horizontal
                      ? Row(
                          children: [
                            Expanded(child: tablero),
                            const SizedBox(width: AppTheme.espacio),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [_marcador(), const SizedBox(height: AppTheme.espacio), _botonesDireccion()],
                              ),
                            ),
                          ],
                        )
                      : Column(
                          children: [
                            _marcador(),
                            Expanded(child: tablero),
                            _botonesDireccion(),
                          ],
                        ),
                ),
              ),
      ),
    );
  }
}
