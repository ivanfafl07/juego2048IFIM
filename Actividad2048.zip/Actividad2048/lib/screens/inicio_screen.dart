import 'package:flutter/material.dart';

import '../data/partida_guardada_dao.dart';
import '../routes.dart';
import '../services/preferencias_service.dart';
import '../services/sesion.dart';
import '../theme/app_theme.dart';
import '../widgets/confirm_dialog.dart';
import '../widgets/score_card.dart';

class InicioScreen extends StatefulWidget {
  final void Function(int pestana) onIrAPestana; // Para que los botones cambien de pestaña

  const InicioScreen({super.key, required this.onIrAPestana});

  @override
  State<InicioScreen> createState() => _InicioScreenState();
}

class _InicioScreenState extends State<InicioScreen> {
  final _guardadaDao = PartidaGuardadaDao();
  int _mejor = 0;
  bool _hayPartidaGuardada = false;

  @override
  void initState() {
    super.initState();
    _cargarDatos();
  }

  Future<void> _cargarDatos() async {
    try {
      final mejor = await PreferenciasService.leerMejorPuntuacion();
      final guardada = await _guardadaDao.obtener(Sesion.nombre);
      if (!mounted) return;
      setState(() {
        _mejor = mejor;
        _hayPartidaGuardada = guardada != null;
      });
    } catch (e) {
      _aviso('Error al leer los datos guardados');
    }
  }

  void _aviso(String texto) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  Future<void> _abrirJuego({required bool continuar}) async {
    await Navigator.pushNamed(context, AppRoutes.juego, arguments: continuar);
    _cargarDatos(); // Al volver puede haber cambiado el récord o la partida guardada
  }

  Future<void> _nuevaPartida() async {
    if (_hayPartidaGuardada) {
      final respuesta = await ConfirmDialog.mostrar(
        context,
        titulo: 'Nueva partida',
        mensaje: 'Tienes una partida guardada. Si empiezas otra, se perderá.',
        textoConfirmar: 'Empezar nueva',
      );
      if (respuesta != RespuestaDialogo.confirmar) return;
      try {
        await _guardadaDao.borrar();
      } catch (e) {
        _aviso('No se pudo borrar la partida guardada');
        return;
      }
    }
    if (mounted) _abrirJuego(continuar: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppTheme.espacio),
          children: [
            const Text('2048', style: AppTheme.estiloTitulo, textAlign: TextAlign.center),
            Text('Hola, ${Sesion.nombre}', textAlign: TextAlign.center),
            const SizedBox(height: AppTheme.espacio),
            ScoreCard(etiqueta: 'MEJOR', valor: _mejor),
            const SizedBox(height: AppTheme.espacio),
            if (_hayPartidaGuardada) ...[
              FilledButton.icon(
                onPressed: () => _abrirJuego(continuar: true),
                icon: const Icon(Icons.play_arrow),
                label: const Text('Continuar partida'),
              ),
              const SizedBox(height: AppTheme.espacio / 2),
            ],
            FilledButton.icon(
              onPressed: _nuevaPartida,
              icon: const Icon(Icons.add),
              label: const Text('Nueva partida'),
            ),
            const SizedBox(height: AppTheme.espacio / 2),
            OutlinedButton(onPressed: () => widget.onIrAPestana(1), child: const Text('Historial')),
            const SizedBox(height: AppTheme.espacio / 2),
            OutlinedButton(onPressed: () => widget.onIrAPestana(2), child: const Text('Ranking')),
            const SizedBox(height: AppTheme.espacio / 2),
            OutlinedButton(onPressed: () => widget.onIrAPestana(3), child: const Text('Ajustes')),
          ],
        ),
      ),
    );
  }
}
