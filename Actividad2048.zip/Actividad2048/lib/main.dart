import 'package:flutter/material.dart';

import 'routes.dart';
import 'services/tema_controller.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Necesario para usar plugins antes de runApp
  await temaController.cargar(); // Leemos el tema ANTES de pintar nada: así no parpadea
  runApp(const App2048());
}

class App2048 extends StatelessWidget {
  const App2048({super.key});

  @override
  Widget build(BuildContext context) {
    // Cada vez que temaController llama a notifyListeners, se reconstruye MaterialApp con el tema nuevo
    return ListenableBuilder(
      listenable: temaController,
      builder: (context, _) {
        return MaterialApp(
          title: '2048',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.claro(temaController.paletaFichas),
          darkTheme: AppTheme.oscuro(temaController.paletaFichas),
          themeMode: temaController.modo,
          initialRoute: AppRoutes.login,
          onGenerateRoute: AppRoutes.generarRuta,
        );
      },
    );
  }
}
