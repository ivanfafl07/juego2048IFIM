import 'package:sqflite/sqflite.dart';

import '../models/partida_guardada.dart';
import 'database_helper.dart';

// Guardar, recuperar y borrar la partida en curso (tabla partida_guardada)
class PartidaGuardadaDao {
  Future<Database> get _db => DatabaseHelper.instance.database;

  // Como el id siempre es 1, replace sobrescribe la partida anterior
  Future<void> guardar(PartidaGuardada partida) async {
    final db = await _db;
    await db.insert('partida_guardada', partida.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // Devuelve la partida guardada de ese usuario, o null si no tiene
  Future<PartidaGuardada?> obtener(String usuario) async {
    final db = await _db;
    final filas = await db.query(
      'partida_guardada',
      where: 'id = ? AND usuario = ?',
      whereArgs: [PartidaGuardada.idUnico, usuario],
    );
    if (filas.isEmpty) return null;
    return PartidaGuardada.fromMap(filas.first);
  }

  Future<void> borrar() async {
    final db = await _db;
    await db.delete('partida_guardada', where: 'id = ?', whereArgs: [PartidaGuardada.idUnico]);
  }
}
