import 'package:sqflite/sqflite.dart';

import '../models/estadisticas.dart';
import '../models/partida.dart';
import '../models/partida_guardada.dart';
import 'database_helper.dart';

// Todas las consultas de la tabla partidas (historial, ranking y estadísticas)
class PartidaDao {
  Future<Database> get _db => DatabaseHelper.instance.database;

  // ---------- CRUD ----------

  Future<int> insertar(Partida partida) async {
    final db = await _db;
    return db.insert('partidas', partida.toMap());
  }

  // Historial ordenado por fecha (la más reciente primero).
  // Sin filtros (jugador vacío y fichaMinima 0) devuelve el historial completo
  Future<List<Partida>> obtenerHistorial({String jugador = '', int fichaMinima = 0}) async {
    final db = await _db;
    final filas = await db.query(
      'partidas',
      where: 'usuario LIKE ? AND ficha_maxima >= ?',
      whereArgs: ['%$jugador%', fichaMinima], // El texto va como parámetro, nunca dentro del SQL
      orderBy: 'fecha DESC',
    );
    return filas.map((f) => Partida.fromMap(f)).toList();
  }

  Future<Partida?> obtenerPorId(int id) async {
    final db = await _db;
    final filas = await db.query('partidas', where: 'id = ?', whereArgs: [id]);
    if (filas.isEmpty) return null;
    return Partida.fromMap(filas.first);
  }

  Future<int> eliminar(int id) async {
    final db = await _db;
    return db.delete('partidas', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> eliminarTodas() async {
    final db = await _db;
    return db.delete('partidas');
  }

  // ---------- TRANSACCIÓN ----------

  // Al terminar una partida: guardarla en el historial y borrar la partida en curso.
  // Dentro de la transacción se usa txn: si algo falla, no se hace ninguna de las dos cosas
  Future<void> registrarPartidaTerminada(Partida partida) async {
    final db = await _db;
    await db.transaction((txn) async {
      await txn.insert('partidas', partida.toMap());
      await txn.delete('partida_guardada', where: 'id = ?', whereArgs: [PartidaGuardada.idUnico]);
    });
  }

  // ---------- CONSULTAS CON ORDENACIÓN Y AGREGADOS ----------

  // Las 10 mejores partidas (ORDER BY + LIMIT)
  Future<List<Partida>> top10() async {
    final db = await _db;
    final filas = await db.query('partidas', orderBy: 'puntuacion DESC', limit: 10);
    return filas.map((f) => Partida.fromMap(f)).toList();
  }

  // COUNT, MAX, AVG y SUM en una sola consulta
  Future<EstadisticasGlobales> estadisticasGlobales() async {
    final db = await _db;
    final filas = await db.rawQuery('''
      SELECT COUNT(*) AS total,
             MAX(puntuacion) AS maxima,
             AVG(puntuacion) AS media,
             MAX(ficha_maxima) AS ficha,
             SUM(duracion_segundos) AS tiempo
      FROM partidas
    ''');
    return EstadisticasGlobales.fromMap(filas.first);
  }

  // Una fila por jugador (GROUP BY)
  Future<List<EstadisticaJugador>> estadisticasPorJugador() async {
    final db = await _db;
    final filas = await db.rawQuery('''
      SELECT usuario, MAX(puntuacion) AS mejor, COUNT(*) AS partidas
      FROM partidas
      GROUP BY usuario
      ORDER BY mejor DESC
    ''');
    return filas.map((f) => EstadisticaJugador.fromMap(f)).toList();
  }
}
