import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

// Abre la base de datos game2048.db. Es un singleton: solo hay una conexión en toda la app
class DatabaseHelper {
  static const String nombreBD = 'game2048.db';

  // Versión 1: tablas del enunciado
  // Versión 2: se añade la columna tamano_tablero a partidas (ver _onUpgrade)
  static const int version = 2;

  DatabaseHelper._(); // Constructor privado: nadie puede hacer new DatabaseHelper()
  static final DatabaseHelper instance = DatabaseHelper._();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _abrir(); // Solo se abre la primera vez
    return _db!;
  }

  Future<Database> _abrir() async {
    final ruta = join(await getDatabasesPath(), nombreBD);
    return openDatabase(
      ruta,
      version: version,
      onConfigure: _onConfigure,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  // Se ejecuta cada vez que se abre: activa las claves foráneas (en SQLite vienen apagadas)
  Future<void> _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  // Solo se ejecuta si la BD no existe: crea el esquema completo de la última versión
  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT NOT NULL UNIQUE,
        fecha_registro TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        contrasena TEXT NOT NULL
      )
    ''');

    // partidas.usuario es clave foránea a usuarios.usuario (modelo normalizado)
    await db.execute('''
      CREATE TABLE partidas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT NOT NULL,
        puntuacion INTEGER NOT NULL,
        ficha_maxima INTEGER NOT NULL,
        movimientos INTEGER NOT NULL,
        duracion_segundos INTEGER NOT NULL,
        fecha TEXT NOT NULL,
        tamano_tablero INTEGER NOT NULL DEFAULT 4,
        FOREIGN KEY (usuario) REFERENCES usuarios (usuario) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE partida_guardada (
        id INTEGER PRIMARY KEY,
        usuario TEXT NOT NULL,
        tablero TEXT NOT NULL,
        puntuacion INTEGER NOT NULL,
        movimientos INTEGER NOT NULL,
        segundos_transcurridos INTEGER NOT NULL,
        FOREIGN KEY (usuario) REFERENCES usuarios (usuario) ON DELETE CASCADE
      )
    ''');
  }

  // Solo se ejecuta si el móvil tenía una versión anterior. ALTER TABLE no borra los datos que ya había
  Future<void> _onUpgrade(Database db, int versionVieja, int versionNueva) async {
    if (versionVieja < 2) {
      await db.execute('ALTER TABLE partidas ADD COLUMN tamano_tablero INTEGER NOT NULL DEFAULT 4');
    }
  }
}
