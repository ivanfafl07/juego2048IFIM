import 'package:sqflite/sqflite.dart';

import '../models/usuario.dart';
import 'database_helper.dart';

// Todas las consultas de la tabla usuarios
class UsuarioDao {
  Future<Database> get _db => DatabaseHelper.instance.database;

  // Devuelve el usuario con su id. Lanza una Exception si el nombre o el email ya existen
  Future<Usuario> registrar(Usuario usuario) async {
    final db = await _db;
    try {
      final id = await db.insert('usuarios', usuario.toMap());
      return Usuario(
        id: id,
        usuario: usuario.usuario,
        email: usuario.email,
        contrasena: usuario.contrasena,
        fechaRegistro: usuario.fechaRegistro,
      );
    } on DatabaseException catch (e) {
      if (e.isUniqueConstraintError()) {
        throw Exception('Ese usuario o email ya está registrado');
      }
      rethrow;
    }
  }

  // contrasenaEncriptada ya viene con el hash hecho. Devuelve null si no coincide
  Future<Usuario?> login(String usuario, String contrasenaEncriptada) async {
    final db = await _db;
    final filas = await db.query(
      'usuarios',
      where: 'usuario = ? AND contrasena = ?',
      whereArgs: [usuario, contrasenaEncriptada],
    );
    if (filas.isEmpty) return null;
    return Usuario.fromMap(filas.first);
  }
}
