import 'dart:math';

enum Direccion { arriba, abajo, izquierda, derecha }

// Lógica del juego. No sabe nada de pantallas ni de base de datos
class Juego2048 {
  static const int lado = 4;

  final List<int> tablero; // 16 casillas: índice = fila * 4 + columna. 0 = vacía
  int puntuacion;
  int movimientos;
  final Random _random = Random();

  // Partida nueva: tablero vacío con dos fichas
  Juego2048()
      : tablero = List.filled(lado * lado, 0),
        puntuacion = 0,
        movimientos = 0 {
    _ponerFichaNueva();
    _ponerFichaNueva();
  }

  // Partida recuperada de la base de datos
  Juego2048.desdeGuardado(List<int> tableroGuardado, this.puntuacion, this.movimientos)
      : tablero = List.of(tableroGuardado);

  int get fichaMaxima => tablero.reduce(max);

  // Un 2 (90 %) o un 4 (10 %) en una casilla vacía al azar
  void _ponerFichaNueva() {
    final vacias = <int>[];
    for (var i = 0; i < tablero.length; i++) {
      if (tablero[i] == 0) vacias.add(i);
    }
    if (vacias.isEmpty) return;
    final casilla = vacias[_random.nextInt(vacias.length)];
    tablero[casilla] = _random.nextInt(10) == 0 ? 4 : 2;
  }

  // Índices de una fila o columna, ordenados en el sentido del movimiento.
  // Así todas las direcciones se resuelven como si fuera "mover a la izquierda"
  List<int> _indicesLinea(int n, Direccion direccion) {
    switch (direccion) {
      case Direccion.izquierda:
        return [n * 4, n * 4 + 1, n * 4 + 2, n * 4 + 3];
      case Direccion.derecha:
        return [n * 4 + 3, n * 4 + 2, n * 4 + 1, n * 4];
      case Direccion.arriba:
        return [n, n + 4, n + 8, n + 12];
      case Direccion.abajo:
        return [n + 12, n + 8, n + 4, n];
    }
  }

  // Junta las fichas hacia el principio y fusiona las iguales: [2, 0, 2, 4] -> [4, 4, 0, 0]
  List<int> _deslizar(List<int> linea) {
    final numeros = linea.where((v) => v != 0).toList();
    final resultado = <int>[];
    var i = 0;
    while (i < numeros.length) {
      if (i + 1 < numeros.length && numeros[i] == numeros[i + 1]) {
        final suma = numeros[i] * 2;
        resultado.add(suma);
        puntuacion += suma;
        i += 2; // Las dos fichas se han convertido en una
      } else {
        resultado.add(numeros[i]);
        i++;
      }
    }
    while (resultado.length < lado) {
      resultado.add(0);
    }
    return resultado;
  }

  // Devuelve true si el tablero ha cambiado (solo entonces cuenta como movimiento)
  bool mover(Direccion direccion) {
    final antes = List.of(tablero);
    for (var n = 0; n < lado; n++) {
      final indices = _indicesLinea(n, direccion);
      final linea = [for (final i in indices) tablero[i]];
      final nueva = _deslizar(linea);
      for (var k = 0; k < lado; k++) {
        tablero[indices[k]] = nueva[k];
      }
    }

    var haCambiado = false;
    for (var i = 0; i < tablero.length; i++) {
      if (tablero[i] != antes[i]) haCambiado = true;
    }
    if (haCambiado) {
      movimientos++;
      _ponerFichaNueva();
    }
    return haCambiado;
  }

  // Fin de partida: no quedan huecos ni dos fichas iguales juntas
  bool get sinMovimientos {
    if (tablero.contains(0)) return false;
    for (var i = 0; i < tablero.length; i++) {
      final columna = i % lado;
      if (columna < lado - 1 && tablero[i] == tablero[i + 1]) return false; // Vecina de la derecha
      if (i + lado < tablero.length && tablero[i] == tablero[i + lado]) return false; // Vecina de abajo
    }
    return true;
  }
}
