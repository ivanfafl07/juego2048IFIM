import 'package:flutter/material.dart';

import '../models/partida.dart';
import '../theme/app_theme.dart';
import '../utils.dart';
import 'tile_widget.dart';

// Resumen de una partida para las listas del historial y del ranking
class PartidaListItem extends StatelessWidget {
  final Partida partida;
  final int? posicion; // Solo en el ranking (1, 2, 3...)
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const PartidaListItem({super.key, required this.partida, this.posicion, this.onTap, this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: SizedBox(
          width: AppTheme.tamanoFichaLista,
          height: AppTheme.tamanoFichaLista,
          child: TileWidget(valor: partida.fichaMaxima),
        ),
        title: Text('${partida.puntuacion} puntos'),
        subtitle: Text('${partida.usuario} · ${formatearFecha(partida.fecha)}'),
        trailing: posicion != null
            ? Text('#$posicion', style: Theme.of(context).textTheme.titleMedium)
            : Text(formatearDuracion(partida.duracionSegundos)),
        onTap: onTap,
        onLongPress: onLongPress,
      ),
    );
  }
}
