import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// Tarjeta con icono, valor y título para una estadística
class StatCard extends StatelessWidget {
  final String titulo;
  final String valor;
  final IconData icono;

  const StatCard({super.key, required this.titulo, required this.valor, required this.icono});

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    return SizedBox(
      width: AppTheme.anchoStatCard,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.espacio / 2),
          child: Column(
            children: [
              Icon(icono, color: tema.colorScheme.primary),
              Text(valor, style: tema.textTheme.titleLarge),
              Text(titulo, style: tema.textTheme.bodySmall, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
