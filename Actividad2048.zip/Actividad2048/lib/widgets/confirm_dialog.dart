import 'package:flutter/material.dart';

enum RespuestaDialogo { confirmar, alternativa, cancelar }

// Diálogo de confirmación genérico. textoAlternativo es un tercer botón opcional
// (lo usa la pantalla de juego: "Guardar y salir" / "Salir sin guardar" / "Cancelar")
class ConfirmDialog extends StatelessWidget {
  final String titulo;
  final String mensaje;
  final String textoConfirmar;
  final String textoCancelar;
  final String? textoAlternativo;

  const ConfirmDialog({
    super.key,
    required this.titulo,
    required this.mensaje,
    this.textoConfirmar = 'Aceptar',
    this.textoCancelar = 'Cancelar',
    this.textoAlternativo,
  });

  // Abre el diálogo y espera la respuesta. Tocar fuera cuenta como cancelar
  static Future<RespuestaDialogo> mostrar(
    BuildContext context, {
    required String titulo,
    required String mensaje,
    String textoConfirmar = 'Aceptar',
    String textoCancelar = 'Cancelar',
    String? textoAlternativo,
  }) async {
    final respuesta = await showDialog<RespuestaDialogo>(
      context: context,
      builder: (_) => ConfirmDialog(
        titulo: titulo,
        mensaje: mensaje,
        textoConfirmar: textoConfirmar,
        textoCancelar: textoCancelar,
        textoAlternativo: textoAlternativo,
      ),
    );
    return respuesta ?? RespuestaDialogo.cancelar;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(titulo),
      content: Text(mensaje),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, RespuestaDialogo.cancelar),
          child: Text(textoCancelar),
        ),
        if (textoAlternativo != null)
          TextButton(
            onPressed: () => Navigator.pop(context, RespuestaDialogo.alternativa),
            child: Text(textoAlternativo!),
          ),
        FilledButton(
          onPressed: () => Navigator.pop(context, RespuestaDialogo.confirmar),
          child: Text(textoConfirmar),
        ),
      ],
    );
  }
}
