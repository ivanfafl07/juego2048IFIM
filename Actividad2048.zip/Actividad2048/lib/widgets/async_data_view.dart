import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils.dart';

// Muestra los tres estados de una consulta a la BD: cargando, error (con reintentar) o los datos
class AsyncDataView<T> extends StatelessWidget {
  final Future<T> future;
  final Widget Function(BuildContext context, T datos) builder;
  final VoidCallback onReintentar;

  const AsyncDataView({super.key, required this.future, required this.builder, required this.onReintentar});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: future,
      builder: (context, snapshot) {
        final terminado = snapshot.connectionState == ConnectionState.done;

        if (terminado && snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(AppTheme.espacio),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline, size: 48),
                  Text('Error: ${textoError(snapshot.error!)}', textAlign: TextAlign.center),
                  const SizedBox(height: AppTheme.espacio),
                  FilledButton(onPressed: onReintentar, child: const Text('Reintentar')),
                ],
              ),
            ),
          );
        }

        // Al recargar seguimos enseñando los datos anteriores mientras llegan los nuevos
        if (terminado || snapshot.hasData) {
          return builder(context, snapshot.data as T);
        }

        return const Center(child: CircularProgressIndicator());
      },
    );
  }
}
