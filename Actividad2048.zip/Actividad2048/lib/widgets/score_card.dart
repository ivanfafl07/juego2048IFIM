import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// Etiqueta + número, por ejemplo "PUNTOS 1024" o "MEJOR 2048"
class ScoreCard extends StatelessWidget {
  final String etiqueta;
  final int valor;

  const ScoreCard({super.key, required this.etiqueta, required this.valor});

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    return Card(
      color: tema.colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.espacio / 2),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(etiqueta, style: tema.textTheme.labelMedium),
            Text('$valor', style: tema.textTheme.headlineSmall),
          ],
        ),
      ),
    );
  }
}
