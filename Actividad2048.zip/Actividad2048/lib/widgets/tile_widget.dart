import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// Una ficha del tablero. Lee sus colores del tema activo
class TileWidget extends StatelessWidget {
  final int valor; // 0 = casilla vacía

  const TileWidget({super.key, required this.valor});

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).extension<ColoresFichas>()!;

    // ANIMACIÓN: cuando cambia el valor (ficha nueva o fusión), la ficha nueva aparece creciendo
    return AnimatedSwitcher(
      duration: AppTheme.duracionAnimacion,
      transitionBuilder: (child, animacion) => ScaleTransition(scale: animacion, child: child),
      child: Container(
        key: ValueKey(valor), // Si cambia la key, AnimatedSwitcher lanza la animación
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: colores.colorDe(valor),
          borderRadius: BorderRadius.circular(AppTheme.radio),
        ),
        child: valor == 0
            ? null
            : Padding(
                padding: const EdgeInsets.all(AppTheme.espacioPequeno),
                child: FittedBox(
                  child: Text('$valor', style: AppTheme.estiloFicha.copyWith(color: colores.textoDe(valor))),
                ),
              ),
      ),
    );
  }
}
