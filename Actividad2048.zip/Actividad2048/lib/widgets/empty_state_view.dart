import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// Se muestra cuando una lista no tiene datos
class EmptyStateView extends StatelessWidget {
  final IconData icono;
  final String mensaje;

  const EmptyStateView({super.key, required this.icono, required this.mensaje});

  @override
  Widget build(BuildContext context) {
    final tema = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.all(AppTheme.espacio * 2),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 64, color: tema.colorScheme.outline),
          const SizedBox(height: AppTheme.espacio),
          Text(mensaje, style: tema.textTheme.bodyLarge, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
