import 'package:flutter/material.dart';

import '../logic/juego_2048.dart';
import '../theme/app_theme.dart';
import 'tile_widget.dart';

// Tablero 4x4. Recibe los valores y avisa con onMover cuando el usuario desliza.
// Es Stateful solo para recordar dónde empezó el dedo
class BoardWidget extends StatefulWidget {
  final List<int> tablero;
  final void Function(Direccion direccion) onMover;

  const BoardWidget({super.key, required this.tablero, required this.onMover});

  @override
  State<BoardWidget> createState() => _BoardWidgetState();
}

class _BoardWidgetState extends State<BoardWidget> {
  Offset _inicio = Offset.zero;
  Offset _fin = Offset.zero;

  // Al soltar el dedo: si el recorrido supera el umbral, gana el eje con más desplazamiento
  void _alSoltar() {
    final dx = _fin.dx - _inicio.dx;
    final dy = _fin.dy - _inicio.dy;
    if (dx.abs() < AppTheme.umbralDeslizamiento && dy.abs() < AppTheme.umbralDeslizamiento) {
      return; // Movimiento demasiado corto: se ignora
    }
    if (dx.abs() > dy.abs()) {
      widget.onMover(dx > 0 ? Direccion.derecha : Direccion.izquierda);
    } else {
      widget.onMover(dy > 0 ? Direccion.abajo : Direccion.arriba);
    }
  }

  @override
  Widget build(BuildContext context) {
    // onPan (y no onHorizontalDrag/onVerticalDrag) porque así tenemos el desplazamiento
    // en los dos ejes a la vez y podemos elegir nosotros la dirección dominante
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (d) => _inicio = _fin = d.localPosition,
      onPanUpdate: (d) => _fin = d.localPosition,
      onPanEnd: (_) => _alSoltar(),
      child: AspectRatio(
        aspectRatio: 1,
        child: Container(
          padding: const EdgeInsets.all(AppTheme.espacioPequeno),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(AppTheme.radio),
          ),
          child: Column(
            children: [
              for (var fila = 0; fila < Juego2048.lado; fila++)
                Expanded(
                  child: Row(
                    children: [
                      for (var col = 0; col < Juego2048.lado; col++)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(AppTheme.espacioPequeno),
                            child: TileWidget(valor: widget.tablero[fila * Juego2048.lado + col]),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
