import 'package:flutter/material.dart';

import 'screens/detalle_screen.dart';
import 'screens/juego_screen.dart';
import 'screens/login_screen.dart';
import 'screens/principal_screen.dart';

// Todas las rutas de la app en un único archivo
class AppRoutes {
  static const String login = '/';
  static const String principal = '/principal'; // Inicio, Historial, Ranking y Ajustes (barra inferior)
  static const String juego = '/juego'; // Argumento: bool -> true = continuar la partida guardada
  static const String detalle = '/detalle'; // Argumento: int -> id de la partida

  static Route<dynamic> generarRuta(RouteSettings settings) {
    switch (settings.name) {
      case principal:
        return MaterialPageRoute(builder: (_) => const PrincipalScreen());
      case juego:
        final continuar = settings.arguments as bool? ?? false;
        return MaterialPageRoute(builder: (_) => JuegoScreen(continuar: continuar));
      case detalle:
        final id = settings.arguments as int;
        return MaterialPageRoute(builder: (_) => DetalleScreen(partidaId: id));
      default:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
    }
  }
}
