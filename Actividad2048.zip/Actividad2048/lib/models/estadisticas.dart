// Resultado de la consulta con COUNT, MAX, AVG y SUM
class EstadisticasGlobales {
  final int partidasJugadas;
  final int puntuacionMaxima;
  final double puntuacionMedia;
  final int fichaMaxima;
  final int tiempoTotalSegundos;

  const EstadisticasGlobales({
    required this.partidasJugadas,
    required this.puntuacionMaxima,
    required this.puntuacionMedia,
    required this.fichaMaxima,
    required this.tiempoTotalSegundos,
  });

  // Si no hay partidas, MAX/AVG/SUM devuelven null: usamos 0
  factory EstadisticasGlobales.fromMap(Map<String, Object?> map) {
    return EstadisticasGlobales(
      partidasJugadas: map['total'] as int? ?? 0,
      puntuacionMaxima: map['maxima'] as int? ?? 0,
      puntuacionMedia: (map['media'] as num? ?? 0).toDouble(),
      fichaMaxima: map['ficha'] as int? ?? 0,
      tiempoTotalSegundos: map['tiempo'] as int? ?? 0,
    );
  }
}

// Una fila de la consulta con GROUP BY usuario
class EstadisticaJugador {
  final String usuario;
  final int mejorPuntuacion;
  final int numPartidas;

  const EstadisticaJugador({required this.usuario, required this.mejorPuntuacion, required this.numPartidas});

  factory EstadisticaJugador.fromMap(Map<String, Object?> map) {
    return EstadisticaJugador(
      usuario: map['usuario'] as String,
      mejorPuntuacion: map['mejor'] as int,
      numPartidas: map['partidas'] as int,
    );
  }
}
