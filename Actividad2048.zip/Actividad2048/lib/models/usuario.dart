// Una fila de la tabla usuarios
class Usuario {
  final int? id; // null hasta que se inserta en la BD
  final String usuario;
  final String email;
  final String contrasena; // Ya encriptada (hash SHA-256), nunca en texto plano
  final String fechaRegistro; // ISO 8601

  const Usuario({
    this.id,
    required this.usuario,
    required this.email,
    required this.contrasena,
    required this.fechaRegistro,
  });

  // Objeto -> Map para guardarlo en la BD
  Map<String, Object?> toMap() {
    return {
      'id': id,
      'usuario': usuario,
      'email': email,
      'contrasena': contrasena,
      'fecha_registro': fechaRegistro,
    };
  }

  // Map de la BD -> objeto
  factory Usuario.fromMap(Map<String, Object?> map) {
    return Usuario(
      id: map['id'] as int,
      usuario: map['usuario'] as String,
      email: map['email'] as String,
      contrasena: map['contrasena'] as String,
      fechaRegistro: map['fecha_registro'] as String,
    );
  }
}
