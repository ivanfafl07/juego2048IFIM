import 'dart:convert';

// La partida en curso. Solo existe una, por eso su id es siempre 1
class PartidaGuardada {
  static const int idUnico = 1;

  final String usuario; // Columna añadida: de quién es la partida guardada
  final List<int> tablero; // 16 casillas, 0 = vacía
  final int puntuacion;
  final int movimientos;
  final int segundosTranscurridos;

  const PartidaGuardada({
    required this.usuario,
    required this.tablero,
    required this.puntuacion,
    required this.movimientos,
    required this.segundosTranscurridos,
  });

  Map<String, Object?> toMap() {
    return {
      'id': idUnico,
      'usuario': usuario,
      'tablero': jsonEncode(tablero), // La lista se guarda como texto JSON: "[2,0,4,...]"
      'puntuacion': puntuacion,
      'movimientos': movimientos,
      'segundos_transcurridos': segundosTranscurridos,
    };
  }

  factory PartidaGuardada.fromMap(Map<String, Object?> map) {
    final lista = jsonDecode(map['tablero'] as String) as List;
    return PartidaGuardada(
      usuario: map['usuario'] as String,
      tablero: lista.map((v) => v as int).toList(),
      puntuacion: map['puntuacion'] as int,
      movimientos: map['movimientos'] as int,
      segundosTranscurridos: map['segundos_transcurridos'] as int,
    );
  }
}
