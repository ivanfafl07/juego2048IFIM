import 'dart:math';

import 'package:flutter/material.dart';

// Colores de las fichas metidos dentro del ThemeData.
// Los widgets los leen con Theme.of(context).extension<ColoresFichas>()
class ColoresFichas extends ThemeExtension<ColoresFichas> {
  final List<Color> colores; // [0] = ficha 2, [1] = ficha 4, ... [10] = ficha 2048
  final Color casillaVacia;

  const ColoresFichas({required this.colores, required this.casillaVacia});

  Color colorDe(int valor) {
    if (valor == 0) return casillaVacia;
    var posicion = 0;
    var v = valor;
    while (v > 2) {
      v = v ~/ 2;
      posicion++;
    }
    return colores[min(posicion, colores.length - 1)];
  }

  // Texto negro sobre colores claros y blanco sobre oscuros, para que se lea en los dos temas
  Color textoDe(int valor) => colorDe(valor).computeLuminance() > 0.45 ? Colors.black87 : Colors.white;

  @override
  ColoresFichas copyWith({List<Color>? colores, Color? casillaVacia}) {
    return ColoresFichas(colores: colores ?? this.colores, casillaVacia: casillaVacia ?? this.casillaVacia);
  }

  @override
  ColoresFichas lerp(ColoresFichas? other, double t) => other ?? this;
}

// Todos los valores visuales de la app en un solo sitio
class AppTheme {
  static const double espacio = 16;
  static const double espacioPequeno = 4;
  static const double radio = 8;
  static const double tamanoFichaLista = 44;
  static const double anchoStatCard = 150;
  static const double umbralDeslizamiento = 40; // Píxeles mínimos para que cuente como swipe
  static const Duration duracionAnimacion = Duration(milliseconds: 150);

  static const TextStyle estiloTitulo = TextStyle(fontSize: 64, fontWeight: FontWeight.bold);
  static const TextStyle estiloFicha = TextStyle(fontSize: 32, fontWeight: FontWeight.bold);

  // Paletas que se pueden elegir en Ajustes (se guarda el índice en shared_preferences)
  static const List<String> nombresPaletas = ['Clásica', 'Azul', 'Verde'];
  static const List<Color> coloresPaletas = [Color(0xFFF65E3B), Color(0xFF1E88E5), Color(0xFF2E7D32)];

  static ThemeData claro(int paleta) => _crearTema(paleta, Brightness.light);
  static ThemeData oscuro(int paleta) => _crearTema(paleta, Brightness.dark);

  static ThemeData _crearTema(int paleta, Brightness brillo) {
    final base = coloresPaletas[paleta % coloresPaletas.length];
    final esClaro = brillo == Brightness.light;

    // Las fichas van de un color suave (ficha 2) hasta el color de la paleta (ficha 2048)
    final inicio = esClaro ? const Color(0xFFEEE4DA) : const Color(0xFF4A4642);
    final fichas = ColoresFichas(
      colores: [for (var i = 1; i <= 11; i++) Color.lerp(inicio, base, i / 11)!],
      casillaVacia: esClaro ? const Color(0xFFCDC1B4) : const Color(0xFF2B2926),
    );

    return ThemeData(
      colorSchemeSeed: base,
      brightness: brillo,
      extensions: [fichas],
      // Mismo estilo de botones en todas las pantallas
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
      ),
    );
  }
}
