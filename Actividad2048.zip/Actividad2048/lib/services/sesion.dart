import '../models/usuario.dart';

// Usuario que ha iniciado sesión
class Sesion {
  static Usuario? usuario;

  static String get nombre => usuario?.usuario ?? '';
}
