import 'package:flutter/material.dart';

import 'preferencias_service.dart';

// Guarda el tema elegido y avisa a la app (notifyListeners) para que cambie al momento
class TemaController extends ChangeNotifier {
  ThemeMode modo = ThemeMode.system;
  int paletaFichas = 0;

  // Se llama en main() antes de runApp, así la app arranca ya con el tema correcto
  Future<void> cargar() async {
    modo = await PreferenciasService.leerModoTema();
    paletaFichas = await PreferenciasService.leerPaletaFichas();
  }

  Future<void> cambiarModo(ThemeMode nuevo) async {
    modo = nuevo;
    notifyListeners();
    await PreferenciasService.guardarModoTema(nuevo);
  }

  Future<void> cambiarPaleta(int indice) async {
    paletaFichas = indice;
    notifyListeners();
    await PreferenciasService.guardarPaletaFichas(indice);
  }
}

// Una única instancia para toda la app
final temaController = TemaController();
