import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Único sitio de la app que usa SharedPreferences
class PreferenciasService {
  // Claves como constantes para no repetir textos por el código
  static const String claveModoTema = 'modo_tema';
  static const String clavePaletaFichas = 'paleta_fichas';
  static const String claveUltimoJugador = 'ultimo_jugador';
  static const String claveMejorPuntuacion = 'mejor_puntuacion';

  // ---------- Tema (claro, oscuro o sistema) ----------

  static Future<void> guardarModoTema(ThemeMode modo) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(claveModoTema, modo.name); // "light", "dark" o "system"
  }

  static Future<ThemeMode> leerModoTema() async {
    final prefs = await SharedPreferences.getInstance();
    final guardado = prefs.getString(claveModoTema);
    for (final modo in ThemeMode.values) {
      if (modo.name == guardado) return modo;
    }
    return ThemeMode.system; // Si no hay nada guardado
  }

  // ---------- Color de las fichas ----------

  static Future<void> guardarPaletaFichas(int indice) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(clavePaletaFichas, indice);
  }

  static Future<int> leerPaletaFichas() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(clavePaletaFichas) ?? 0;
  }

  // ---------- Ampliación opcional: último jugador y mejor puntuación ----------

  static Future<void> guardarUltimoJugador(String nombre) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(claveUltimoJugador, nombre);
  }

  static Future<String> leerUltimoJugador() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(claveUltimoJugador) ?? '';
  }

  static Future<void> guardarMejorPuntuacion(int puntos) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(claveMejorPuntuacion, puntos);
  }

  static Future<int> leerMejorPuntuacion() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(claveMejorPuntuacion) ?? 0;
  }
}
